Hola,

unicamente se requiere tener python instalado, y correrlo con
python3 ticktackToe.py 

Jorge Antonio Arizpe Cantú A01637441
Aaron Hernandez Jimenez A01642529

